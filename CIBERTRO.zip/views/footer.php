<!-- Pie de página -->
<footer class="bg-dark text-white text-center py-1">
    <div class="container">
        <p>&copy; <?php echo date("Y"); ?> Cibertronic S.R.L. Todos los derechos reservados.</p>
        <p>
            <a href="" class="text-white">Política de Privacidad</a> |
            <a href="" class="text-white">Términos de Servicio</a>
        </p>
    </div>
</footer>

<!-- Scripts de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>