<?php
require_once __DIR__ . '/../config/config.php';

function getAdminData($conn, $user_id)
{
    // Consulta SQL para obtener datos del administrador y del usuario asociado
    $sql = "SELECT a.*, u.correo, u.rol, u.estado 
            FROM administrador a
            INNER JOIN usuarios u ON a.usuario_id = u.id
            WHERE a.usuario_id = ?";

    // Preparar y ejecutar la consulta de forma segura
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id);  // Enlaza el parámetro del ID de usuario
        $stmt->execute();
        $result = $stmt->get_result();     // Obtiene el resultado de la consulta
        return $result->fetch_assoc();     // Retorna los datos como array asociativo
    } else {
        // Si falla la preparación, registra el error en el log
        error_log("❌ Error al preparar consulta getAdminData: " . $conn->error);
        return null;  // Retorna null en caso de error
    }
}
